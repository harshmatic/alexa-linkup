var speechOut ='';
var res1= 
{
    "empLeaveDetails": [
        {
            "startDate": "5/8/2017",
            "endDate": "5/12/2017",
            "type": "Leave",
            "status": "Approved"
        },
        {
            "startDate": "5/5/2017",
            "endDate": "5/5/2017",
            "type": "Leave",
            "status": "Approved"
        },
        {
            "startDate": "5/31/2017",
            "endDate": "5/31/2017",
            "type": "Leave",
            "status": "Approved"
        }
    ],
    "gender": "Female"
}

res1.empLeaveDetails.forEach(function(leave,index) {
  speechOut = speechOut+ leave.type + ' from <say-as interpret-as="date"> '+leave.startDate+'</say-as> to ' +leave.endDate;
  res1.empLeaveDetails.length == index+1 ? (speechOut = speechOut+ '.') : (speechOut = speechOut+ ' and ')
});

console.log(speechOut);