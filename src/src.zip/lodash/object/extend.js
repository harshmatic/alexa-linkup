module.exports = require('./assign');
