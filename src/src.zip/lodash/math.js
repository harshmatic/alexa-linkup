module.exports = {
  'add': require('./math/add'),
  'ceil': require('./math/ceil'),
  'floor': require('./math/floor'),
  'max': require('./math/max'),
  'min': require('./math/min'),
  'round': require('./math/round'),
  'sum': require('./math/sum')
};
