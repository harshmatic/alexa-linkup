var config = {
    url:'https://jsonplaceholder.typicode.com'
};

module.exports = config;