var config = {
    url: 'http://alexa.eternussolutions.com:4500'
};
module.exports = config;